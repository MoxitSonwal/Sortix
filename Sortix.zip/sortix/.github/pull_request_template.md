## What changed?

## Safety impact

Does this change read, move, rename, or delete files? Explain the preview, collision, and undo behavior.

## Verification

- [ ] `python -m unittest discover -s tests -v`
- [ ] `python -m compileall backend app.py`
- [ ] Tested only with temporary folders