---
name: Bug report
about: Report a reproducible Sortix problem
title: "[Bug] "
labels: bug
---

## What happened?

## Steps to reproduce

Use a temporary test folder. Do not include private filenames or file contents.

## Expected behavior

## Environment

- Sortix version:
- Operating system:
- Python version: